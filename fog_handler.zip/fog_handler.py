# fog_handler.py
import json
import boto3

s3 = boto3.client("s3")
BUCKET_NAME = "lorawan-traffic-logs"
OBJECT_KEY = "logs/traffic-latest.csv"

def lambda_handler(event, context=None):
    print("📩 Event received:", json.dumps(event))

    try:
        timestamp = event['timestamp']
        lat = event['location']['lat']
        lng = event['location']['lng']
        count = event['vehicle_count']
        line = f"{timestamp},{lat},{lng},{count}\n"

        s3.put_object(
            Bucket=BUCKET_NAME,
            Key=OBJECT_KEY,
            Body=line,
            ContentType="text/csv"
        )

        print("✅ Data written to S3.")
        return {"statusCode": 200, "body": "Success"}

    except Exception as e:
        print("❌ Error:", str(e))
        return {"statusCode": 500, "body": str(e)}
