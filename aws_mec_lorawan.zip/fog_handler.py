# fog_handler.py
# AWS Lambda function to receive MQTT message from AWS IoT Rule and store in S3

import json
import boto3
from datetime import datetime

s3 = boto3.client('s3')
BUCKET_NAME = 'your-s3-bucket-name'
FILE_NAME = 'data.csv'

def lambda_handler(event, context):
    print("Event Received:", json.dumps(event))
    try:
        message = json.loads(event['Records'][0]['Sns']['Message'])
        timestamp = message['timestamp']
        location = message['location']
        count = message['vehicle_count']
        line = f"{timestamp},{location['lat']},{location['lng']},{count}\n"

        s3.put_object(
            Bucket=BUCKET_NAME,
            Key=FILE_NAME,
            Body=line,
            ContentType='text/csv'
        )
        print("Data written to S3.")
        return {"statusCode": 200, "body": "Success"}
    except Exception as e:
        print("Error:", str(e))
        return {"statusCode": 500, "body": str(e)}
