# lorawan_device.py
# Simulated LoRaWAN device sending MQTT data to AWS IoT Core

import time
import json
import random
from datetime import datetime
import ssl
import paho.mqtt.client as mqtt

MQTT_BROKER = "your-iot-endpoint.amazonaws.com"
MQTT_PORT = 8883
MQTT_TOPIC = "lorawan/traffic"

CA_PATH = "certs/AmazonRootCA1.pem"
CERT_PATH = "certs/device-certificate.pem.crt"
KEY_PATH = "certs/private.pem.key"

def create_payload():
    return {
        "timestamp": datetime.utcnow().isoformat(),
        "location": {"lat": 53.349805, "lng": -6.26031},
        "vehicle_count": random.randint(1, 10)
    }

client = mqtt.Client()
client.tls_set(ca_certs=CA_PATH, certfile=CERT_PATH, keyfile=KEY_PATH, tls_version=ssl.PROTOCOL_TLSv1_2)
client.connect(MQTT_BROKER, MQTT_PORT, 60)

print("LoRaWAN device started. Sending data to AWS IoT Core...")
while True:
    payload = create_payload()
    client.publish(MQTT_TOPIC, json.dumps(payload))
    print("Sent:", payload)
    time.sleep(5)
